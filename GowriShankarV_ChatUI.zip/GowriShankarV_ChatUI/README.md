# ChadAI — Chat Interface

A modern, responsive chat UI built with HTML, CSS, JavaScript, jQuery, and Bootstrap 5.

## How to Run

1. Unzip the folder
2. Open `index.html` in any modern browser (Chrome, Firefox, Safari, Edge)
3. No server or installation required — it works entirely in the browser

## Features

### Core

- Welcome screen with 4 clickable suggestion cards
- Message bubbles with distinct user and AI styling
- Animated typing indicator with bouncing dots
- Auto-resizing textarea input
- Enter to send, Shift+Enter for new line
- Auto-scroll on new messages
- Sidebar with chat history and New Chat button
- Mobile-responsive with hamburger menu and slide-in sidebar

### Bonus Features

- **Dark/Light mode toggle** — smooth CSS variable transition
- **Message formatting** — supports `**bold**`, `*italic*`, `` `inline code` ``, and ` ```code blocks``` `
- **Typewriter animation** — AI responses type out letter by letter
- **Export chat** — downloads full chat as `.txt` using Blob API
- **Custom scrollbar** — styled webkit scrollbar throughout
- **Sound effects** — subtle Web Audio API tones on send and receive

## File Structure

```
ChatUI/
├── index.html         — Main HTML file
├── css/
│   └── style.css      — All custom styles (well-organized + commented)
├── js/
│   └── chat.js        — All JavaScript/jQuery functionality
├── screenshots/
│   ├── desktop        — ss on desktop
│   └── mobile         — ss on mobile
└── README.md          — This file
```

## Technologies Used

- HTML5 (semantic tags: header, main, section, footer, aside)
- CSS3 (custom properties, flexbox, grid, animations, keyframes)
- JavaScript ES6 + jQuery 3.7.1
- Bootstrap 5.3.3
- Font Awesome 6.5.1
- Google Fonts (DM Sans + JetBrains Mono)

## Browser Support

Tested on Chrome 120+, Firefox 121+, Safari 17+, Edge 120+
