/**
 * ChadAI Chat Interface
 * Author: Student
 */

$(function () {
  /* ===========================================================
     CONSTANTS & STATE
     =========================================================== */

  // Sample AI response pool
  const AI_RESPONSES = [
    "That's a great question! Let me break it down for you.\n\nTo understand this properly, it helps to think of it from first principles. The core idea is that **complex systems often emerge from simple rules**, which is why understanding the foundational concepts matters so much.\n\nWould you like me to dive deeper into any specific aspect?",
    "Sure! Here's a clear explanation:\n\n**Key Points:**\n- The concept is well-established in academic literature\n- There are multiple approaches depending on your use case\n- Practice is more effective than passive reading\n\nI'd recommend starting with the fundamentals and building up gradually. What's your current level of familiarity with this topic?",
    "Great question! Here's a Python example:\n\n```python\ndef solve(problem):\n    # Break the problem into smaller steps\n    steps = analyze(problem)\n    result = []\n    \n    for step in steps:\n        result.append(process(step))\n    \n    return result\n```\n\nThis pattern — breaking a problem into smaller, manageable chunks — is one of the most powerful techniques in programming. Does this help clarify things?",
    "I understand what you're asking. Let me give you a thorough answer.\n\nThe short answer is: **it depends on your specific context**. However, in most cases, the recommended approach is to start simple and iterate as you learn more.\n\nThe longer explanation involves understanding the trade-offs between different approaches. Would you like me to walk you through those in detail?",
    "Absolutely! This is actually a really interesting topic.\n\nHistorically, this concept evolved over decades of research. The key milestones were:\n1. **Early foundations** in the mid-20th century\n2. **Major breakthroughs** in the 1990s and 2000s\n3. **Modern applications** that we see today\n\nEach stage built on the previous one, which is why understanding the history helps clarify the present. Want me to expand on any of these?",
    "Of course! Let me think through this step by step.\n\nFirst, we need to identify the *underlying structure* of the problem. Once we do that, the solution becomes much clearer.\n\nThe most elegant approach here is to use a **divide and conquer** strategy — break the big problem into smaller ones, solve each independently, and combine the results.\n\nShall I show you a concrete example?",
  ];

  let messageCount = 0; // Track number of sent messages
  let isTyping = false; // Guard against double-sends
  let chatHistory = []; // Store messages for export
  let letterByLetterQueue = []; // Queue for typewriter effect

  /* ===========================================================
     UTILITY: GET CURRENT TIME
     =========================================================== */
  function getCurrentTime() {
    return new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  /* ===========================================================
     FORMAT MESSAGE TEXT
     =========================================================== */
  function formatMessage(text) {
    // Escape HTML first (prevent XSS)
    let formatted = $("<div>").text(text).html();

    // Code blocks (```lang\n...\n```)
    formatted = formatted.replace(
      /```(\w*)\n?([\s\S]*?)```/g,
      function (_, lang, code) {
        const langLabel = lang || "code";
        return `<div class="code-block-header">
                  <span>${langLabel}</span>
                  <button class="copy-code-btn" data-code="${encodeURIComponent(code.trim())}">Copy</button>
                </div>
                <pre><code>${code.trim()}</code></pre>`;
      },
    );

    // Inline code (`code`)
    formatted = formatted.replace(/`([^`]+)`/g, "<code>$1</code>");

    // Bold (**text**)
    formatted = formatted.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");

    // Italic (*text*)
    formatted = formatted.replace(/\*(.+?)\*/g, "<em>$1</em>");

    // Numbered list (1. item)
    formatted = formatted.replace(/^\d+\.\s(.+)$/gm, "<li>$1</li>");
    formatted = formatted.replace(/(<li>[\s\S]+?<\/li>)+/g, "<ol>$&</ol>");

    // Bullet list (- item)
    formatted = formatted.replace(/^-\s(.+)$/gm, "<li>$1</li>");
    formatted = formatted.replace(
      /(?<!<\/ol>)(<li>[\s\S]+?<\/li>)+(?!<\/ol>)/g,
      "<ul>$&</ul>",
    );

    // Newlines → <br>
    formatted = formatted.replace(/\n/g, "<br>");

    return formatted;
  }

  /* ===========================================================
     ADD MESSAGE
     =========================================================== */
  function addMessage(text, sender) {
    const time = getCurrentTime();
    const isUser = sender === "user";
    const avatarChar = isUser ? "S" : '<i class="fa-solid fa-infinity"></i>';
    const senderName = isUser ? "You" : "ChadAI";
    const rowClass = isUser ? "user" : "ai";
    const formattedText = formatMessage(text);

    const $row = $(`
      <div class="message-row ${rowClass}">
        <div class="msg-avatar">${avatarChar}</div>
        <div class="msg-content-wrap">
          <div class="msg-header">
            <span class="msg-sender">${senderName}</span>
            <span class="msg-time">${time}</span>
          </div>
          <div class="msg-bubble">${isUser ? formattedText : ""}</div>
        </div>
      </div>
    `);

    $("#chatMessages").append($row);

    // Typewriter effect for AI messages
    if (!isUser) {
      typewriterEffect($row.find(".msg-bubble"), formattedText);
    }

    // Store in history for export
    chatHistory.push({ sender: senderName, text, time });

    scrollToBottom();
    return $row;
  }

  /* ===========================================================
     TYPEWRITER EFFECT 
     =========================================================== */
  function typewriterEffect($el, html) {
    // We'll type the visible text, then swap to full HTML at end
    // Extract plain-ish text for typing, then reveal formatted HTML
    const plainText = $("<div>").html(html).text();
    let i = 0;
    $el.text("");
    $el.css("min-height", "1.5em");

    const interval = setInterval(function () {
      if (i < plainText.length) {
        $el.text(plainText.slice(0, i + 1));
        i++;
        // Keep scrolled to bottom while typing
        scrollToBottom();
      } else {
        clearInterval(interval);
        // Swap to fully formatted HTML
        $el.html(html);
        // Bind copy buttons that may have appeared
        bindCopyButtons();
        scrollToBottom();
      }
    }, 12); // ~80 chars/sec feels natural
  }

  /* ===========================================================
     SCROLL TO BOTTOM
     =========================================================== */
  function scrollToBottom() {
    const $section = $("#messagesSection");
    $section
      .stop(true)
      .animate({ scrollTop: $section[0].scrollHeight }, 220, "swing");
  }

  /* ===========================================================
     SHOW / HIDE TYPING INDICATOR
     =========================================================== */
  function showTyping() {
    $("#typingIndicator").fadeIn(200);
    scrollToBottom();
  }

  function hideTyping() {
    $("#typingIndicator").fadeOut(150);
  }

  /* ===========================================================
     HIDE WELCOME SCREEN
     =========================================================== */
  function hideWelcome() {
    if ($("#welcomeScreen").is(":visible")) {
      $("#welcomeScreen").fadeOut(300, function () {
        $(this).remove();
      });
    }
  }

  /* ===========================================================
     SEND MESSAGE
     =========================================================== */
  function sendMessage() {
    const text = $("#userInput").val().trim();
    if (!text || isTyping) return;

    isTyping = true;

    // Hide welcome screen on first message
    hideWelcome();

    // Add user message
    addMessage(text, "user");

    // Clear & reset input
    $("#userInput").val("").trigger("input");
    $("#sendBtn").prop("disabled", true);

    // Show typing indicator
    showTyping();

    // Simulate AI response delay (1–2 seconds)
    const delay = 1000 + Math.random() * 1000;

    setTimeout(function () {
      hideTyping();

      // Pick a random AI response
      const response =
        AI_RESPONSES[Math.floor(Math.random() * AI_RESPONSES.length)];
      addMessage(response, "ai");

      isTyping = false;
    }, delay);
  }

  /* ===========================================================
     INPUT HANDLING
     =========================================================== */

  // Enable/disable send button based on input content
  $("#userInput").on("input", function () {
    const hasText = $(this).val().trim().length > 0;
    $("#sendBtn").prop("disabled", !hasText);

    // Auto-resize textarea
    this.style.height = "auto";
    this.style.height = Math.min(this.scrollHeight, 160) + "px";
  });

  // Enter to send; Shift+Enter for newline
  $("#userInput").on("keydown", function (e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  // Send button click
  $("#sendBtn").on("click", function () {
    sendMessage();
  });

  /* ===========================================================
     SUGGESTION CARDS
     =========================================================== */
  $(document).on("click", ".suggestion-card", function () {
    const prompt = $(this).data("prompt");
    if (prompt) {
      $("#userInput").val(prompt).trigger("input");
      $("#userInput").focus();
      sendMessage();
    }
  });

  /* ===========================================================
     SIDEBAR MOBILE TOGGLE
     =========================================================== */
  $("#hamburgerBtn").on("click", function () {
    openSidebar();
  });

  $("#sidebarOverlay").on("click", function () {
    closeSidebar();
  });

  function openSidebar() {
    $("#sidebar").addClass("open");
    $("#sidebarOverlay").addClass("active");
    $("body").css("overflow", "hidden");
  }

  function closeSidebar() {
    $("#sidebar").removeClass("open");
    $("#sidebarOverlay").removeClass("active");
    $("body").css("overflow", "");
  }

  // Close sidebar on history item click (mobile)
  $(document).on("click", ".history-item", function () {
    if ($(window).width() <= 768) closeSidebar();

    // Highlight active item
    $(".history-item").removeClass("active");
    $(this).addClass("active");
  });

  /* ===========================================================
     NEW CHAT BUTTON
     =========================================================== */
  $("#newChatBtn").on("click", function () {
    // Clear messages
    $("#chatMessages").empty();
    chatHistory = [];
    messageCount = 0;
    isTyping = false;
    $("#typingIndicator").hide();

    // Re-show welcome screen
    if ($("#welcomeScreen").length === 0) {
      const $welcome = $(`
        <div class="welcome-screen" id="welcomeScreen">
          <div class="welcome-content">
            <div class="welcome-icon"><i class="fa-solid fa-infinity"></i></div>
            <h1 class="welcome-title">Hello, Student.</h1>
            <p class="welcome-subtitle">Ask me anything — I'm here to help you learn, create, and explore.</p>
            <div class="suggestion-grid">
              <div class="suggestion-card" data-prompt="Explain the difference between machine learning and deep learning">
                <div class="card-icon"><i class="fa-solid fa-brain"></i></div>
                <div class="card-body-text"><h3>Explain ML vs Deep Learning</h3><p>Understand core AI concepts clearly</p></div>
              </div>
              <div class="suggestion-card" data-prompt="Write a Python function to sort a list using bubble sort">
                <div class="card-icon"><i class="fa-solid fa-code"></i></div>
                <div class="card-body-text"><h3>Code a sorting algorithm</h3><p>Get working code with explanations</p></div>
              </div>
              <div class="suggestion-card" data-prompt="Help me write a professional email to my professor requesting an extension">
                <div class="card-icon"><i class="fa-solid fa-envelope-open-text"></i></div>
                <div class="card-body-text"><h3>Draft a professional email</h3><p>Write to your professor or recruiter</p></div>
              </div>
              <div class="suggestion-card" data-prompt="Summarize the key events of the French Revolution in 5 bullet points">
                <div class="card-icon"><i class="fa-solid fa-scroll"></i></div>
                <div class="card-body-text"><h3>Summarize history notes</h3><p>Get quick study-ready summaries</p></div>
              </div>
            </div>
          </div>
        </div>
      `);
      $(".messages-wrapper").prepend($welcome);
    }

    // Add new entry to history
    const $newItem = $(`
      <li class="history-item">
        <i class="fa-regular fa-message"></i>
        <span>New Chat</span>
      </li>
    `);
    $(".history-item").removeClass("active");
    $newItem.addClass("active");
    $("#historyList").prepend($newItem);

    $("#userInput").val("").trigger("input").focus();

    if ($(window).width() <= 768) closeSidebar();
  });

  /* ===========================================================
     DARK MODE TOGGLE
     =========================================================== */
  let isDark = true; // Default is dark

  $("#themeToggle").on("click", function () {
    isDark = !isDark;
    $("html").attr("data-theme", isDark ? "dark" : "light");
    $("#themeIcon").attr(
      "class",
      isDark ? "fa-solid fa-moon" : "fa-solid fa-sun",
    );
    $("#themeLabel").text(isDark ? "Dark Mode" : "Light Mode");
  });

  /* ===========================================================
     EXPORT CHAT HISTORY
     =========================================================== */
  $("#exportBtn").on("click", function () {
    if (chatHistory.length === 0) {
      alert("No messages to export yet. Start a conversation first!");
      return;
    }

    let content = "ChadAI Chat Export\n";
    content += "=".repeat(40) + "\n";
    content += `Exported: ${new Date().toLocaleString()}\n`;
    content += "=".repeat(40) + "\n\n";

    chatHistory.forEach(function (msg) {
      content += `[${msg.time}] ${msg.sender}:\n${msg.text}\n\n`;
      content += "-".repeat(30) + "\n\n";
    });

    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const $a = $("<a>").attr({ href: url, download: "chadai-chat.txt" });
    $("body").append($a);
    $a[0].click();
    $a.remove();
    URL.revokeObjectURL(url);
  });

  /* ===========================================================
     COPY CODE BUTTON
     =========================================================== */
  function bindCopyButtons() {
    $(document)
      .off("click", ".copy-code-btn")
      .on("click", ".copy-code-btn", function () {
        const code = decodeURIComponent($(this).data("code"));
        navigator.clipboard.writeText(code).then(() => {
          const $btn = $(this);
          $btn.text("Copied!");
          setTimeout(() => $btn.text("Copy"), 2000);
        });
      });
  }

  bindCopyButtons(); // initial bind

  /* ===========================================================
     SEND SOUNDS
     =========================================================== */
  function playSound(type) {
    // Use Web Audio API for lightweight sound effects (no external files needed)
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === "send") {
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(1100, ctx.currentTime + 0.08);
        gain.gain.setValueAtTime(0.08, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.15);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.15);
      } else {
        osc.frequency.setValueAtTime(660, ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(880, ctx.currentTime + 0.08);
        gain.gain.setValueAtTime(0.06, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.18);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.18);
      }
    } catch (e) {
      // Audio not supported — fail silently
    }
  }

  // Patch sendMessage to play sound
  const _origSend = sendMessage;
  // Override: play sound on send
  $("#sendBtn")
    .off("click")
    .on("click", function () {
      if ($("#userInput").val().trim()) {
        playSound("send");
        sendMessage();
      }
    });

  $("#userInput")
    .off("keydown")
    .on("keydown", function (e) {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        if ($(this).val().trim()) {
          playSound("send");
          sendMessage();
        }
      }
    });

  /* ===========================================================
     PLAY RECEIVE SOUND AFTER AI RESPONDS
     =========================================================== */
  // Patch the typing timeout to also play sound
  // (We do this by observing DOM changes on chatMessages)
  const observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (m) {
      m.addedNodes.forEach(function (node) {
        if ($(node).hasClass("message-row") && $(node).hasClass("ai")) {
          setTimeout(() => playSound("receive"), 300);
        }
      });
    });
  });
  observer.observe(document.getElementById("chatMessages"), {
    childList: true,
  });

  /* ===========================================================
     INIT: Focus input
     =========================================================== */
  $("#userInput").focus();
});
